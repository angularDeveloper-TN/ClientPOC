﻿using CustomerReaderExcercise.Model;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.IO;

namespace CustomerReaderExcercise.CustomerFileReader
{
    class JsonReader : ReaderTemplate
    {
        protected override void ExtractData(string filePath, ref List<Customer> customerList)
        {
            JsonTextReader reader = new JsonTextReader(System.IO.File.OpenText(filePath));

            try
            {
                JArray obj = (JArray)JToken.ReadFrom(reader);

                foreach (JObject o in obj)
                {
                    Customer customer = new Customer();
                    JObject record = (JObject)o;

                    customer.sEmail = (string)record["Email"];

                    customer.sFirstName = (string)record["FirstName"];

                    customer.sLastName = (string)record["LastName"];

                    customer.sPhone = (string)record["PhoneNumber"];

                    JObject address = (JObject)record["Address"];

                    customer.CustomerAddress.sStreetAddress = (string)address["StreetAddress"];

                    customer.CustomerAddress.sCity = (string)address["City"];

                    customer.CustomerAddress.sState = (string)address["State"];

                    customer.CustomerAddress.sZipCode = (string)address["ZipCode"];

                    customerList.Add(customer);
                }
            }
            catch (FileNotFoundException e)
            {
                Console.Write(e.StackTrace);
            }
            catch (IOException e)
            {
                Console.Write(e.StackTrace);
            }
            catch (JsonException e)
            {
                Console.Write(e.StackTrace);
            }
        }
    }
}
