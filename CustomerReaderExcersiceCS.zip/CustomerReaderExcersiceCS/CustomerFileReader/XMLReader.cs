﻿using CustomerReaderExcercise.Model;
using System;
using System.Collections.Generic;
using System.Xml;

namespace CustomerReaderExcercise.CustomerFileReader
{
    class XmlReader : ReaderTemplate
    {
        protected override void ExtractData(string filePath, ref List<Customer> customerList)
        {
            try
            {
                var doc = new XmlDocument();
                doc.Load(filePath);

                XmlNodeList nList = doc.GetElementsByTagName("Customer");

                for (int temp = 0; temp < nList.Count; temp++)
                {
                    XmlNode nNode = nList[temp];
                    if (nNode.NodeType == XmlNodeType.Element)
                    {
                        Customer customer = new Customer();
                        XmlElement eElement = (XmlElement)nNode;

                        customer.sEmail = eElement.GetElementsByTagName("Email").Item(0).InnerText;
                        customer.sFirstName = eElement.GetElementsByTagName("FirstName").Item(0).InnerText;
                        customer.sLastName = eElement.GetElementsByTagName("LastName").Item(0).InnerText;
                        customer.sPhone = eElement.GetElementsByTagName("PhoneNumber").Item(0).InnerText;

                        XmlElement aElement = (XmlElement)eElement.GetElementsByTagName("Address").Item(0);

                        customer.CustomerAddress.sStreetAddress = aElement.GetElementsByTagName("StreetAddress").Item(0).InnerText;
                        customer.CustomerAddress.sCity = aElement.GetElementsByTagName("City").Item(0).InnerText;
                        customer.CustomerAddress.sState = aElement.GetElementsByTagName("State").Item(0).InnerText;
                        customer.CustomerAddress.sZipCode = aElement.GetElementsByTagName("ZipCode").Item(0).InnerText;

                        customerList.Add(customer);
                    }
                }
            }
            catch (Exception e)
            {
                Console.Write(e.StackTrace);
            }
        }
    }
}
