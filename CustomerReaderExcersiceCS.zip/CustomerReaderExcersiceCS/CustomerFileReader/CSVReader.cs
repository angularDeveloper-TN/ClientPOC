﻿using CustomerReaderExcercise.Model;
using System;
using System.Collections.Generic;
using System.IO;

namespace CustomerReaderExcercise.CustomerFileReader
{
    public class CsvReader : ReaderTemplate
    {
        protected override  void ExtractData(string filePath, ref List<Customer> customerList)
        {
            try
            {
                StreamReader br = new StreamReader(File.Open(filePath, FileMode.Open));
                string line = br.ReadLine();

                while (line != null)
                {
                    string[] attributes = line.Split(',');
                    if (attributes[0] != "email")
                    {
                        Customer customer = new Customer();
                        customer.sEmail = attributes[0];
                        customer.sFirstName = attributes[1];
                        customer.sLastName = attributes[2];
                        customer.sPhone = attributes[3];
                        customer.CustomerAddress.sStreetAddress = attributes[4];
                        customer.CustomerAddress.sCity = attributes[5];
                        customer.CustomerAddress.sState = attributes[6];
                        customer.CustomerAddress.sZipCode = attributes[7];
                        customerList.Add(customer);
                    }
                    line = br.ReadLine();
                }
            }
            catch (IOException ex)
            {
                Console.Write("OH NO!!!!");
                Console.Write(ex.StackTrace);
            }
        }
    }
}
