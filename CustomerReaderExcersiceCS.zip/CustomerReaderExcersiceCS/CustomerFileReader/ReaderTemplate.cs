﻿using CustomerReaderExcercise.Model;
using System.Collections.Generic;

namespace CustomerReaderExcercise.CustomerFileReader
{
    public abstract class ReaderTemplate : IDataReader
    {
        public void FillCustomerList(string filePath, ref List<Customer> customerList)
        {
            ExtractData(filePath, ref customerList);
        }

        protected abstract void ExtractData(string filePath, ref List<Customer> customerList);
    }
}
