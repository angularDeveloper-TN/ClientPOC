﻿using CustomerReaderExcercise.Model;
using System.Collections.Generic;

namespace CustomerReaderExcercise
{
    public interface IDataReader
    {
        void FillCustomerList(string filePath, ref List<Customer> customerList);
    }
}
