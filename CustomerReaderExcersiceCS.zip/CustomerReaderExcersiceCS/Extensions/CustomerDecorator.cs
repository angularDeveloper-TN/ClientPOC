﻿namespace CustomerReaderExcercise.Extensions
{
    public abstract class CustomerDecorator
    {
        protected ICustomerDetail CustomerDetail;

        protected CustomerDecorator(ICustomerDetail customerDetail)
        {
            CustomerDetail = customerDetail;
        }
        public virtual void PrintCustomerInfo()
        {
            CustomerDetail?.PrintCustomerInfo();
        }
    }
}
