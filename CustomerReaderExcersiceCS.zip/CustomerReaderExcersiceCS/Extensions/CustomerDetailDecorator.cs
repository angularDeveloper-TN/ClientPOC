﻿namespace CustomerReaderExcercise.Extensions
{
    public class CustomerDetailDecorator : CustomerDecorator
    {
        public CustomerDetailDecorator(ICustomerDetail iCustomerDetail) : base(iCustomerDetail)
        {

        }
        /// <summary>
        /// Enhanced Format print.
        /// </summary>
        public override void PrintCustomerInfo()
        {
            if (CustomerDetail != null)
            {
                FormatString();
                base.PrintCustomerInfo();
            }
        }
        private void FormatString()
        {
            var customerList = CustomerDetail.GetCustomerDetails();
            foreach(var customer in customerList)
            {
                customer.sFirstName = FirstLetterToUpper(customer.sFirstName.ToLower().Trim());
                customer.sLastName = FirstLetterToUpper(customer.sLastName.ToLower().Trim());
                customer.sEmail = customer.sEmail.ToLower();
                customer.CustomerAddress.sState = customer.CustomerAddress.sState.ToUpper();
                customer.CustomerAddress.sCity = FirstLetterToUpper(customer.CustomerAddress.sCity.ToLower().Trim());
                customer.CustomerAddress.sStreetAddress = FirstCharToUpper(customer.CustomerAddress.sStreetAddress);
            }    
        }

        private string FirstLetterToUpper(string sValue)
        {
            if (string.IsNullOrEmpty(sValue))
            {
                return string.Empty;
            }
            return char.ToUpper(sValue[0]) + sValue.Substring(1);
        }

        private string FirstCharToUpper(string sValue)
        {
            char[] array = sValue.ToCharArray();
            if (array.Length >= 1)
            {
                if (char.IsLower(array[0]))
                {
                    array[0] = char.ToUpper(array[0]);
                }
            }
            for (int i = 1; i < array.Length; i++)
            {
                if (array[i - 1] == ' ')
                {
                    if (char.IsLower(array[i]))
                    {
                        array[i] = char.ToUpper(array[i]);
                    }
                }
            }
            return new string(array);
        }
    }
}
