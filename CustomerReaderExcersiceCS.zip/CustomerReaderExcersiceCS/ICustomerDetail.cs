﻿using CustomerReaderExcercise.Model;
using System.Collections.Generic;

namespace CustomerReaderExcercise
{
    public interface ICustomerDetail
    {
        int GetCustomerCount();
        void ReadCustomerData(string filePath);
        void PrintCustomerInfo();
        ref List<Customer> GetCustomerDetails();
    }
}
