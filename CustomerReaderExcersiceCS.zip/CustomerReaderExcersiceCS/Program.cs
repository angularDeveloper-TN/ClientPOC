﻿using System;
using CustomerReaderExcercise.Domain;
using CustomerReaderExcercise.Extensions;
using CustomerReaderExcercise.Model;

namespace CustomerReaderExcercise
{
    class Program
    {
        static void Main(string[] args)
        {

            ICustomerDetail iCustomerDetailCsv = new CustomerDetail(FileType.Csv);
            ICustomerDetail iCustomerDetailXml = new CustomerDetail(FileType.Xml);
            ICustomerDetail iCustomerDetailJson = new CustomerDetail(FileType.Json);

            iCustomerDetailCsv.ReadCustomerData("..\\..\\Files\\customers.csv");
            iCustomerDetailXml.ReadCustomerData("..\\..\\Files\\customers.xml");
            iCustomerDetailJson.ReadCustomerData("..\\..\\Files\\customers.json");

            Console.WriteLine("Added this many customers: " + (iCustomerDetailCsv.GetCustomerCount() + iCustomerDetailXml.GetCustomerCount() + iCustomerDetailJson.GetCustomerCount()) + "\n");

            CustomerDecorator customerDecoratorCsv = new CustomerDetailDecorator(iCustomerDetailCsv);
            CustomerDecorator customerDecoratorXml = new CustomerDetailDecorator(iCustomerDetailXml);
            CustomerDecorator customerDecoratorJson = new CustomerDetailDecorator(iCustomerDetailJson);

            customerDecoratorCsv.PrintCustomerInfo();
            customerDecoratorXml.PrintCustomerInfo();
            customerDecoratorJson.PrintCustomerInfo();

            Console.ReadLine();
        }
    }
}
