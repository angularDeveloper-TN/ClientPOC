﻿using CustomerReaderExcercise.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using CustomerReaderExcercise.CustomerFileReader;
using System.Text;

namespace CustomerReaderExcercise.Domain
{
   public class CustomerDetail : ICustomerDetail
    {
        private List<Customer> _customerList;
        private readonly IDataReader _iDataReader;
        public  CustomerDetail(FileType fileType)
        {
            _customerList = new List<Customer>();
            switch (fileType)
            {
                case FileType.Csv:
                    _iDataReader = new CsvReader();
                    break;
                case FileType.Json:
                    _iDataReader = new JsonReader();
                    break;
                case FileType.Xml: 
                    _iDataReader = new XmlReader();
                    break;
            }
        }

        public int GetCustomerCount()
        {
            return _customerList.Count();
        }

        public void PrintCustomerInfo()
        {
            foreach (Customer customer in this._customerList)
            {
                string customerString = "";
                customerString += "Email: " + customer.sEmail + "\n";
                customerString += "First Name: " + customer.sFirstName + "\n";
                customerString += "Last Name: " + customer.sLastName + "\n";
                customerString += "Full Name: " + customer.sFirstName + " " + customer.sLastName + "\n";
                customerString += "Phone Number: " + customer.sPhone + "\n";
                customerString += "Street Address: " + customer.CustomerAddress.sStreetAddress + "\n";
                customerString += "City: " + customer.CustomerAddress.sCity + "\n";
                customerString += "State: " + customer.CustomerAddress.sState + "\n";
                customerString += "Zip Code: " + customer.CustomerAddress.sZipCode + "\n";

                Console.WriteLine(customerString);
            }
        }

        public void ReadCustomerData(string filePath)
        {
            _iDataReader.FillCustomerList(filePath,ref _customerList);
        }

        public ref List<Customer> GetCustomerDetails()
        {
            return ref this._customerList;
        }
    }
}
