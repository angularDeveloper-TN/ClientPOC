﻿using System;

namespace CustomerReaderExcercise.Model
{
   public class Address
    {
        private string _sStreetAddress = string.Empty;
        private string _sCity = string.Empty;
        private string _sState = string.Empty;
        private string _sZipCode = string.Empty;

        public string sStreetAddress
        {
            get
            {
                return _sStreetAddress;
            }
            set
            {
                _sStreetAddress = value;
            }
        }
        public string sCity
        {
            get
            {
                return _sCity;
            }
            set
            {
                _sCity = value;
            }
        }
        public string sState
        {
            get
            {
                return _sState;
            }
            set
            {
                _sState = value;
            }
        }
        public string sZipCode
        {
            get
            {
                return _sZipCode;
            }
            set
            {
                _sZipCode = value;
            }
        }
    }
}
