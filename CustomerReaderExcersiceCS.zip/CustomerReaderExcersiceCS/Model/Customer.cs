﻿using System;
using System.Runtime.Remoting.Messaging;

namespace CustomerReaderExcercise.Model
{
    public class Customer 
    {
        public Customer()
        {
            CustomerAddress = new Address();
        }

        private string _sFirstName = string.Empty;
        private string _sLastName = string.Empty;
        private string _sEmail = string.Empty;
        private string _sPhone = string.Empty;

        public string sFirstName
        {
            get
            {
                return _sFirstName;
            }
            set
            {
                _sFirstName = value;
            }
        }
        public string sLastName
        {
            get
            {
                return _sLastName;
            }
            set
            {
                _sLastName = value;
            }
        }
        public string sEmail { 
            get
            {
                return _sEmail;
            }
            set 
            {
                _sEmail = value;
            } 
        }
        public string sPhone
        {
            get
            {
                return _sPhone;
            }
            set
            {
                _sPhone = value;
            }
        }
        public Address CustomerAddress;
    }
}
