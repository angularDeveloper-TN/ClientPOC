﻿namespace CustomerReaderExcercise.Model
{
    public enum FileType
    {
        Csv,
        Xml,
        Json
    }
}
