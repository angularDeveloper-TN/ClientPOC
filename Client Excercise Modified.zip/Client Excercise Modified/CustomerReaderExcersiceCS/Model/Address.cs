﻿namespace CustomerReader.Model
{
   public class Address
    {
        public string sStreet;
        public string sCity;
        public string sState;
        public string sZipCode;
    }
}
