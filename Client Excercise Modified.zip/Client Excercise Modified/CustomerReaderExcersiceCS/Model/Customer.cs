﻿namespace CustomerReader.Model
{
    public class Customer : Address
    {
        public string sFirstName;
        public string sLastName;
        public string sEmail;
        public string sPhone;
    }
}
