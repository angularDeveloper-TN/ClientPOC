﻿namespace CustomerReader.Model
{
   public enum FileType
    {
        Csv,
        Xml,
        Json
    }
}
