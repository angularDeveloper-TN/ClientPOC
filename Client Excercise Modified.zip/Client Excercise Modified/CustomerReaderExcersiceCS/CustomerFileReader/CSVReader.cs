﻿using CustomerReader.Model;
using System;
using System.Collections.Generic;
using System.IO;

namespace CustomerReader.CustomerFileReader
{
    public class CSVReader : IDataReader
    {
        public void FillCustomerList(string filePath, ref List<Customer> customerList)
        {
            try
            {
                StreamReader br = new StreamReader(File.Open(filePath, FileMode.Open));
                String line = br.ReadLine();

                while (line != null)
                { 
                    String[] attributes = line.Split(',');
                    if (attributes[0] != "email")
                    {
                        Customer customer = new Customer();
                        customer.sEmail = attributes[0];
                        customer.sFirstName = attributes[1];
                        customer.sLastName = attributes[2];
                        customer.sPhone = attributes[3];
                        customer.sStreet = attributes[4];
                        customer.sCity = attributes[5];
                        customer.sState = attributes[6];
                        customer.sZipCode = attributes[7];
                        customerList.Add(customer);
                    }        
                    line = br.ReadLine();
                }
            }
            catch (IOException ex)
            {
                Console.Write("OH NO!!!!");
                Console.Write(ex.StackTrace);
            }
        }
    }
}
