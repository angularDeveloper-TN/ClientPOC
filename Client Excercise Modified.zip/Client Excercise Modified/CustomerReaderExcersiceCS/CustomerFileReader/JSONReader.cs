﻿using CustomerReader.Model;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.IO;

namespace CustomerReader.CustomerFileReader
{
    class JSONReader : IDataReader
    {
        public void FillCustomerList(string filePath, ref List<Customer> customerList)
        {
            JsonTextReader reader = new JsonTextReader(System.IO.File.OpenText(filePath));

            try
            {
                JArray obj = (JArray)JToken.ReadFrom(reader);
                //JArray a = (JArray)reader);
                //

                foreach (JObject o in obj)
                {
                    Customer customer = new Customer();
                    JObject record = (JObject)o;

                    customer.sEmail = (string)record["Email"];

                    customer.sFirstName = (string)record["FirstName"];

                    customer.sLastName = (string)record["LastName"];

                    customer.sPhone = (string)record["PhoneNumber"];

                    JObject address = (JObject)record["Address"];

                    customer.sStreet = (string)address["StreetAddress"];

                    customer.sCity = (string)address["City"];

                    customer.sState = (string)address["State"];

                    customer.sZipCode = (string)address["ZipCode"];

                    customerList.Add(customer);
                }
            }
            catch (FileNotFoundException e)
            {
                Console.Write(e.StackTrace);
            }
            catch (IOException e)
            {
                Console.Write(e.StackTrace);
            }
            catch (JsonException e)
            {
                Console.Write(e.StackTrace);
            }
        }
    }
}
