﻿namespace CustomerReader.Helper
{
    public static class CustomerReaderHelper
    {
        public static string FirstCharToUpper(this string sValue)
        {
            char[] array = sValue.ToCharArray();
            if (array.Length >= 1)
            {
                if (char.IsLower(array[0]))
                {
                    array[0] = char.ToUpper(array[0]);
                }
            } 
            for (int i = 1; i < array.Length; i++)
            {
                if (array[i - 1] == ' ')
                {
                    if (char.IsLower(array[i]))
                    {
                        array[i] = char.ToUpper(array[i]);
                    }
                }
            }
            return new string(array);
        }

        public static string FirstLetterToUpper(this string sValue)
        { 
            if (string.IsNullOrEmpty(sValue))
            {
                return string.Empty;
            } 
            return char.ToUpper(sValue[0]) + sValue.Substring(1);
        }
    }
}
