﻿using CustomerReader.Model;
using System.Collections.Generic;

namespace CustomerReader
{
    public interface IDataReader
    {
        void FillCustomerList(string filePath, ref List<Customer> customerList);
    }
}
