﻿using CustomerReader.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CustomerReader.CustomerFileReader;
using CustomerReader.Helper;

namespace CustomerReader.Domain
{
   public class CustomerDetail : ICustomerDetail
    {
        private List<Customer> _customerList;
        private readonly IDataReader _iDataReader;
        public  CustomerDetail(FileType fileType)
        {
            _customerList = new List<Customer>();
            switch (fileType)
            {
                case FileType.Csv:
                    _iDataReader = new CSVReader();
                    break;
                case FileType.Json:
                    _iDataReader = new JSONReader();
                    break;
                case FileType.Xml: 
                    _iDataReader = new XMLReader();
                    break;
            }
        }

        public int GetCustomerCount()
        {
            return _customerList.Count();
        }

        public void PrintCustomerInfo()
        {
            foreach (Customer customer in this._customerList)
            {
                StringBuilder customerString = new StringBuilder();
                customerString.AppendLine("Email: " + customer.email.ToLower());
                customerString.AppendLine("First Name: " + customer.fn.Trim().FirstLetterToUpper());
                customerString.AppendLine("Last Name: " + customer.ln.Trim().FirstLetterToUpper());
                customerString.AppendLine("Full Name: " + customer.fn.Trim().FirstLetterToUpper() + " " + customer.ln.Trim().FirstLetterToUpper());
                customerString.AppendLine("Phone Number: " + customer.phone);
                customerString.AppendLine("Street Address: " + customer.streetAddress.FirstCharToUpper());
                customerString.AppendLine("City: " + customer.city.FirstLetterToUpper());
                customerString.AppendLine("State: " + customer.state.ToUpper());
                customerString.AppendLine("Zip Code: " + customer.zipCode);

                Console.WriteLine(customerString.ToString());
            }
        }

        public void ReadCustomerData(string filePath)
        {
            _iDataReader.FillCustomerList(filePath,ref _customerList);
        }
    }
}
