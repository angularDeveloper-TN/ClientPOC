﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CustomerReader.Model;

namespace CustomerReader
{
    public interface ICustomerDetail
    {
        int GetCustomerCount();
        void ReadCustomerData(string filePath);
        void PrintCustomerInfo();
    }
}
