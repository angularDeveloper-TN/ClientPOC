﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustomerReader.Model
{
    public class Customer : Address
    {
        public String fn;
        public String ln;
        public String email;
        public String phone;
    }
}
