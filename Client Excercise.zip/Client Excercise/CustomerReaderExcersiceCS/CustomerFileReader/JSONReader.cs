﻿using CustomerReader.Model;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustomerReader.CustomerFileReader
{
    class JSONReader : IDataReader
    {
        public void FillCustomerList(string filePath, ref List<Customer> customerList)
        {
            JsonTextReader reader = new JsonTextReader(System.IO.File.OpenText(filePath));

            try
            {
                JArray obj = (JArray)JToken.ReadFrom(reader);
                //JArray a = (JArray)reader);
                //

                foreach (JObject o in obj)
                {
                    Customer customer = new Customer();
                    JObject record = (JObject)o;

                    String email = (String)record["Email"];
                    customer.email = email;

                    String firstName = (String)record["FirstName"];
                    customer.fn = firstName;

                    String lastName = (String)record["LastName"];
                    customer.ln = lastName;

                    String phone = (String)record["PhoneNumber"];
                    customer.phone = phone;

                    JObject address = (JObject)record["Address"];

                    String streetAddress = (String)address["StreetAddress"];
                    customer.streetAddress = streetAddress;

                    String city = (String)address["City"];
                    customer.city = city;

                    String state = (String)address["State"];
                    customer.state = state;

                    String zipCode = (String)address["ZipCode"];
                    customer.zipCode = zipCode;

                    customerList.Add(customer);
                }
            }
            catch (FileNotFoundException e)
            {
                Console.Write(e.StackTrace);
            }
            catch (IOException e)
            {
                Console.Write(e.StackTrace);
            }
            catch (JsonException e)
            {
                Console.Write(e.StackTrace);
            }
        }
    }
}
