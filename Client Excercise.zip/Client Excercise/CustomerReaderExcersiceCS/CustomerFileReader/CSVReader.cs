﻿using CustomerReader.Model;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustomerReader.CustomerFileReader
{
    public class CSVReader : IDataReader
    {
        public void FillCustomerList(string filePath, ref List<Customer> customerList)
        {
            try
            {
                StreamReader br = new StreamReader(File.Open(filePath, FileMode.Open));
                String line = br.ReadLine();

                while (line != null)
                { 
                    String[] attributes = line.Split(',');
                    if (attributes[0] != "email")
                    {
                        Customer customer = new Customer();
                        customer.email = attributes[0];
                        customer.fn = attributes[1];
                        customer.ln = attributes[2];
                        customer.phone = attributes[3];
                        customer.streetAddress = attributes[4];
                        customer.city = attributes[5];
                        customer.state = attributes[6];
                        customer.zipCode = attributes[7];
                        customerList.Add(customer);
                    }        
                    line = br.ReadLine();
                }
            }
            catch (IOException ex)
            {
                Console.Write("OH NO!!!!");
                Console.Write(ex.StackTrace);
            }
        }
    }
}
