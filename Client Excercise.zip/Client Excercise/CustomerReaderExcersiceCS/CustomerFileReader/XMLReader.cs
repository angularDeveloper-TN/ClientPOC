﻿using CustomerReader.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace CustomerReader.CustomerFileReader
{
    class XMLReader : IDataReader
    {
        public void FillCustomerList(string filePath, ref List<Customer> customerList)
        {
            try
            {
                var doc = new XmlDocument();
                doc.Load(filePath);

                XmlNodeList nList = doc.GetElementsByTagName("Customer");

                for (int temp = 0; temp < nList.Count; temp++)
                {
                    XmlNode nNode = nList[temp];
                    //Console.WriteLine("\nCurrent Element :" + nNode.Name);
                    if (nNode.NodeType == XmlNodeType.Element)
                    {
                        Customer customer = new Customer();
                        XmlElement eElement = (XmlElement)nNode;

                        customer.email = eElement.GetElementsByTagName("Email").Item(0).InnerText;
                        customer.fn = eElement.GetElementsByTagName("FirstName").Item(0).InnerText;
                        customer.ln = eElement.GetElementsByTagName("LastName").Item(0).InnerText;
                        customer.phone = eElement.GetElementsByTagName("PhoneNumber").Item(0).InnerText;

                        XmlElement aElement = (XmlElement)eElement.GetElementsByTagName("Address").Item(0);

                        customer.streetAddress = aElement.GetElementsByTagName("StreetAddress").Item(0).InnerText;
                        customer.city = aElement.GetElementsByTagName("City").Item(0).InnerText;
                        customer.state = aElement.GetElementsByTagName("State").Item(0).InnerText;
                        customer.zipCode = aElement.GetElementsByTagName("ZipCode").Item(0).InnerText;

                        customerList.Add(customer);
                    }
                }
            }
            catch (Exception e)
            {
                Console.Write(e.StackTrace);
            }
        }
    }
}
