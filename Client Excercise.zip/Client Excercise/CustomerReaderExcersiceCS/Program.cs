﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CustomerReader.CustomerFileReader;
using CustomerReader.Domain;
using CustomerReader.Model;

namespace CustomerReader
{
    class Program
    {
        static void Main(string[] args)
        {

            ICustomerDetail iCustomerDetailCsv = new CustomerDetail(FileType.Csv);
            ICustomerDetail iCustomerDetailXml = new CustomerDetail(FileType.Xml);
            ICustomerDetail iCustomerDetailJson = new CustomerDetail(FileType.Json);

            iCustomerDetailCsv.ReadCustomerData("..\\..\\Files\\customers.csv");
            iCustomerDetailXml.ReadCustomerData("..\\..\\Files\\customers.xml");
            iCustomerDetailJson.ReadCustomerData("..\\..\\Files\\customers.json");

            Console.WriteLine("Added this many customers: " + (iCustomerDetailCsv.GetCustomerCount() + iCustomerDetailXml.GetCustomerCount() + iCustomerDetailJson.GetCustomerCount()) + "\n");

            iCustomerDetailCsv.PrintCustomerInfo();
            iCustomerDetailXml.PrintCustomerInfo();
            iCustomerDetailJson.PrintCustomerInfo();

            Console.ReadLine();
        }
    }
}
